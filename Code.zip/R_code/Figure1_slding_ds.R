rm(list=ls())

setwd("/home/dell-none/Desktop/0426jiqun")
da<-read.csv('slope_all_SER.csv',header = TRUE)

head(da)
da1 <- subset(da,Position<21551)###删除跨不同CDS的位点

library(ggplot2)
library(RColorBrewer)


mytheme <- theme(panel.grid.major = element_line(colour=brewer.pal(9,"Pastel1")[9],
                                                 linetype = "longdash"),
                 strip.text = element_text(size = 15),
                 panel.background = element_rect(fill='transparent', color="#000000"),
                 panel.border=element_rect(fill='transparent', color='black'),
                 axis.text = element_text(size = 16),
                 axis.text.x = element_text( hjust = 0.6, vjust = 0),
                 axis.title = element_text(size = 20),
                 legend.title = element_text(size = 18),
                 legend.text = element_text(size = 13),
                 legend.background = element_blank())


ggplot(data=da,aes(x=orign_position,y=SER))+
    # geom_ribbon(aes(ymin = 0.0007-1.96*(0.0016/sqrt(8309-1)), ymax = 0.0007+1.96*(0.0016/sqrt(8309-1))), fill = "grey80") +
    # geom_ribbon(aes(ymin = low_ci, ymax = high_ci),fill = "grey",alpha=0.5)+
    
    # geom_point(aes(color=type))+
    geom_line(size=0.8)+
    labs(x='Position(bp)',y='SER')+
    mytheme+
    scale_x_continuous(breaks=seq(0, 30000, 5000))+
    
    geom_vline(aes(xintercept=13466), colour="#990000", linetype="longdash",size=0.6)+
    geom_vline(aes(xintercept=21516), colour="#990000", linetype="longdash",size=0.6)+
    geom_vline(aes(xintercept=25391), colour="#990000", linetype="longdash",size=0.6)+
    geom_vline(aes(xintercept=26243), colour="#990000", linetype="longdash",size=0.6)+
    # geom_vline(aes(xintercept=26157), colour="#990000", linetype="longdash",size=0.6)+
    geom_vline(aes(xintercept=27200), colour="#990000", linetype="longdash",size=0.6)+
    geom_vline(aes(xintercept=28272), colour="#990000", linetype="longdash",size=0.6)+
    geom_vline(aes(xintercept=29118), colour="#990000", linetype="longdash",size=0.6)+
    geom_hline(aes(yintercept=0.0003259356),linetype="dotted",size=0.8)+
    geom_hline(aes(yintercept=0.000645099),linetype="dotted",size=0.8)+
    geom_hline(aes(yintercept=0.0016633049999999997), linetype="dotted", size=0.8)

ggsave("sliding_ds.pdf",dpi=300,device="pdf",width =13.7,height = 6.00)

###-------------------------------------------------------------------------------------------------------------------------------------
###violine plot

rm(list=ls())

setwd("/home/dell-none/Desktop/0426jiqun")
da<-read.csv('slope_all_SER.csv',header = TRUE,sep=',')

head(da)


library(ggplot2)
library(RColorBrewer)

da$Gene = factor(da$Gene, levels=c('ORF1a','ORF1b','S','ORF3a','E','M','ORF6','ORF7a','N'))
mytheme <- theme(panel.grid.major = element_line(colour=brewer.pal(9,"Pastel1")[9],
                                                 linetype = "longdash"),
                 panel.background = element_rect(fill='transparent', color="#000000"),
                 panel.border=element_rect(fill='transparent', color='black'),
                 axis.text = element_text(size = 16),
                 axis.title = element_text(size = 20),
                 legend.title = element_text(size = 18),
                 legend.text = element_text(size = 13),
                 legend.background = element_blank(),
                 strip.text = element_text(size = 20))

ggplot(da, aes(x = Gene, y = SSR))+
  geom_violin(trim = FALSE)+
  geom_boxplot(fill="#3C5488B2", width= .1, outlier.shape = NA) +
  mytheme +
  scale_y_continuous(limit = c(0,0.0022),expand=c(0,0))
p1 <- ggsave("all_box.pdf",dpi=300,device="pdf",width =12,height = 9.00)

da2 <- read.csv('fit_ssr.csv',header = TRUE,sep=',')


da2$Gene = factor(da2$Gene, levels=c('ORF1a','ORF1b','S','N'))

ggplot(da2, aes(x = Gene, y = SSR))+
  geom_violin(trim = FALSE)+
  geom_boxplot(fill="#3C5488B2", width= .1, outlier.shape = NA) +
  mytheme +
  scale_y_continuous(limit = c(0,0.0022),expand=c(0,0))
p1 <- ggsave("1absn_box.pdf",dpi=300,device="pdf",width =12,height = 9.00)

###-----------------------------------------------------------------------------------------------------------------------------------------
###总体SER分布图

rm(list=ls())

setwd('/home/dell-none/Desktop/0426jiqun')


da1 <- read.csv("fit_ssr.csv", header = TRUE)
head(da1)

###拟合分布产生分布的模拟数据
all_density <- read.csv("all_density2.csv", header = TRUE)
head(all_density)



# da1 <- read.csv("slope_SSR.csv", header = TRUE)
# head(da1)
da1$Gene = factor(da1$Gene, levels=c('ORF1a','ORF1b','S','N'))
all_density$Gene = factor(all_density$Gene, levels=c('ORF1a','ORF1b','S','N'))

library(ggplot2)
library(RColorBrewer)
mytheme <- theme(panel.grid.major = element_line(colour=brewer.pal(9,"Pastel1")[9],
                                                 linetype = "longdash"),
                 panel.background = element_rect(fill='transparent', color="#000000"),
                 panel.border=element_rect(fill='transparent', color='black'),
                 axis.text = element_text(size = 16),
                 axis.title = element_text(size = 20),
                 legend.title = element_text(size = 18),
                 legend.text = element_text(size = 13),
                 legend.background = element_blank(),
                 strip.text = element_text(size = 20))


#--------------------------------------------------------------------
p1 <- ggplot(da1, aes(SSR)) +
  geom_histogram(alpha = .5, aes(y=..density..), 
                 position="identity", bins = 50) +
  geom_density(data=all_density,aes(X0),size = .8 ,fill="#E64B35B2",alpha=0.8) +
  scale_x_continuous(limit = c(0, 0.005))+
  
  # geom_density(all_density,aes(X0),size = .8) +
  #stat_function(aes(rate, color = subtype),fun=dbeta) +
  # scale_color_manual(values = brewer.pal(11,"RdBu")[c(2,7)]) +
  # scale_fill_manual(values = brewer.pal(12,"Set3")[c(1,6)]) +
  labs(x = "Synonymous Substitution Rate", y = "Density") +
  mytheme
# scale_x_continuous(limit = c(0, 0.055))+
# scale_y_continuous(limit = c(0, 10))
# facet_wrap(~Gene, scales= "free", ncol = 3)
p1

p1 <- p1+scale_fill_brewer(palette = "RdBu")
#----------------------------------------------------------------------

p1 <- p1+scale_fill_brewer(palette = "RdBu")

p1
p1 <- ggsave("ds_density_fit.pdf",dpi=300,device="pdf",width =12,height = 9.00)

