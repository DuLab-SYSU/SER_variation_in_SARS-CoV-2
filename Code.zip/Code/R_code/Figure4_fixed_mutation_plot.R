rm(list=ls())

setwd("/home/dell-none/Desktop/0426jiqun")
da<-read.csv('key_aa_mutation_for_ssr.csv',header = TRUE)

head(da)
# da1 <- subset(da,Position<13203)

library(ggplot2)
library(RColorBrewer)
library(dplyr)

mytheme <- theme(panel.grid.major = element_line(colour=brewer.pal(9,"Pastel1")[9],
                                                 linetype = "longdash"),
                 strip.text = element_text(size = 15),
                 panel.background = element_rect(fill='transparent', color="#000000"),
                 panel.border=element_rect(fill='transparent', color='black'),
                 axis.text = element_text(size = 16),
                 axis.text.x = element_text( hjust = 0.6, vjust = 0),
                 axis.title = element_text(size = 20),
                 legend.title = element_text(size = 18),
                 legend.text = element_text(size = 13),
                 legend.background = element_blank())


p <- ggplot(da,aes(x=orign_position,y=SSR))+
  # geom_ribbon(aes(ymin = 0.0007-1.96*(0.0016/sqrt(8309-1)), ymax = 0.0007+1.96*(0.0016/sqrt(8309-1))), fill = "grey80") +
  # geom_ribbon(aes(ymin = low_ci, ymax = high_ci),fill = "grey",alpha=0.5)+
  
  geom_point(aes(),size = case_when(da$type=='Key mutation' ~ 4.0, 
                                    # da$type=='Synonumous key mutation' ~ 4.0,# 3.1
                                    da$type=='Not key mutation' ~ 0.5),
             color =case_when(da$type=='Key mutation' ~ "#FFA07A",
                              # da$type=='Synonumous key mutation' ~ "blue",# 3.1
                              da$type=='Not key mutation' ~ "black"))+
  labs(x='Position(bp)',y='Synonymous_substitution_rate')+
  geom_line(size=0.8)+
  mytheme+
  # scale_x_continuous(breaks=seq(0, 30000, 5000))+
  
  # geom_vline(aes(xintercept=13466), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=21516), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=25391), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=26243), colour="#990000", linetype="longdash",size=0.6)+
  # # geom_vline(aes(xintercept=26157), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=27200), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=28272), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=29118), colour="#990000", linetype="longdash",size=0.6)+
  geom_hline(aes(yintercept=0.0003259356),linetype="dotted",size=0.8)+
  geom_hline(aes(yintercept=0.000645099),linetype="dotted",size=0.8)+
  geom_hline(aes(yintercept=0.0016633049999999997), linetype="dotted", size=0.8)

p

s_info <- read.csv('key_aa_mutation.csv',header = TRUE)
library(ggrepel)
library(tidyverse)
head(s_info)

p <- p+geom_text_repel(data=da,aes(x=orign_position, y=SSR,label = label),max.overlaps = Inf)

p

p <- ggsave("sliding_ds_all_key_point.pdf",dpi=300,device="pdf",width =13.7,height = 6.00)
#-----------------------------------------------------------------------------------------------




da2<-read.csv('omicron_sliding.csv',header = TRUE)

head(da2)
# da1 <- subset(da,Position<13203)

library(ggplot2)
library(RColorBrewer)
library(dplyr)

mytheme <- theme(panel.grid.major = element_line(colour=brewer.pal(9,"Pastel1")[9],
                                                 linetype = "longdash"),
                 strip.text = element_text(size = 15),
                 panel.background = element_rect(fill='transparent', color="#000000"),
                 panel.border=element_rect(fill='transparent', color='black'),
                 axis.text = element_text(size = 16),
                 axis.text.x = element_text( hjust = 0.6, vjust = 0),
                 axis.title = element_text(size = 20),
                 legend.title = element_text(size = 18),
                 legend.text = element_text(size = 13),
                 legend.background = element_blank())


p <- ggplot(da2,aes(x=orign_position,y=SSR))+
  # geom_ribbon(aes(ymin = 0.0007-1.96*(0.0016/sqrt(8309-1)), ymax = 0.0007+1.96*(0.0016/sqrt(8309-1))), fill = "grey80") +
  # geom_ribbon(aes(ymin = low_ci, ymax = high_ci),fill = "grey",alpha=0.5)+
  
  geom_point(aes(),size = case_when(da2$type=='Key mutation' ~ 4.0, 
                                    # da$type=='Synonumous key mutation' ~ 4.0,# 3.1
                                    da2$type=='Not key mutation' ~ 0.5),
             color =case_when(da2$type=='Key mutation' ~ "#00BFFF",
                              # da$type=='Synonumous key mutation' ~ "blue",# 3.1
                              da2$type=='Not key mutation' ~ "black"))+
  labs(x='Position(bp)',y='Synonymous_substitution_rate')+
  geom_line(size=0.8)+
  mytheme+
  # scale_x_continuous(breaks=seq(0, 30000, 5000))+
  
  # geom_vline(aes(xintercept=13466), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=21516), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=25391), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=26243), colour="#990000", linetype="longdash",size=0.6)+
  # # geom_vline(aes(xintercept=26157), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=27200), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=28272), colour="#990000", linetype="longdash",size=0.6)+
  # geom_vline(aes(xintercept=29118), colour="#990000", linetype="longdash",size=0.6)+
  geom_hline(aes(yintercept=0.0003259356),linetype="dotted",size=0.8)+
  geom_hline(aes(yintercept=0.000645099),linetype="dotted",size=0.8)+
  geom_hline(aes(yintercept=0.0016633049999999997), linetype="dotted", size=0.8)

p

s_info <- read.csv('key_aa_mutation.csv',header = TRUE)
library(ggrepel)
library(tidyverse)
head(s_info)

p <- p+geom_text_repel(data=da2,aes(x=orign_position, y=SSR,label = label),max.overlaps = Inf)

p

p <- ggsave("sliding_ds_omicron_point.pdf",dpi=300,device="pdf",width =13.7,height = 6.00)
