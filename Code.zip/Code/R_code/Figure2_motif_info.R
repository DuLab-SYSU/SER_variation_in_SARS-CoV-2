rm(list=ls())

setwd("/home/dell-none/Desktop/0426jiqun/0510high_low/")
data2<-read.table('motif_info_fig_only_low_220728.csv',header = TRUE,sep=',')

head(data2)
library(ggplot2)
library(RColorBrewer)
library(ggrepel)
library(tidyverse) 

library(ggsci)
mytheme <- theme(panel.grid.major = element_line(colour=brewer.pal(9,"Pastel1")[9],
                                                 linetype = "longdash"),
                 panel.background = element_rect(fill='transparent', color="#000000"),
                 panel.border=element_rect(fill='transparent', color='black'),
                 axis.text = element_text(size = 16),
                 axis.text.x = element_text(angle = 45, hjust = 1),
                 axis.title = element_text(size = 20),
                 legend.title = element_text(size = 18),
                 legend.text = element_text(size = 13),
                 legend.background = element_blank(),
                 strip.text = element_text(size = 20))
library(reshape2)

data<-melt(data2,id.vars='motif')
head(data)
write.csv(data, file = "motif_per.csv", row.names = FALSE)

###chang oder

#-----------------------------------------------------------------

data2<-read.table('motif_info_fig_only_low_220728.csv',header = TRUE,sep=',')

head(data2)



da<-read.table('motif_per.csv',header = TRUE,sep=',')
head(da)

da$motif <- factor(da$motif)
da$motif <- fct_inorder(da$motif)


p2 <- ggplot(data=da,aes(motif,value,fill=variable))+
  geom_bar(stat="identity",position="stack", color="black", width=0.7,size=0.25)+
  mytheme+
  labs(x ='Motif',y = "Base Percentage of Motif")
p2
p2 <- p2 +  scale_fill_jama(alpha = 0.7)

p2
p2 <- ggsave("motif_per_220808.pdf",dpi=300,device="pdf",width =10,height = 8)
#---------------------------------------------------------------------------
data2<-read.table('motif_info_fig_only_low_220728.csv',header = TRUE,sep=',')
head(data2)

library(lubridate)

data2$motif <- factor(data2$motif)
data2$motif <- fct_inorder(data2$motif)

p3 <- ggplot(data = data2, aes(x=motif,y = length)) + geom_line( stat = "identity",group=1,linetype=2)+
    geom_point(size=5)+
  
    mytheme+
  labs(x ='Motif',y = "Length")+
  scale_y_continuous(breaks=seq(5, 15, 1))
p3 <- p3 +  scale_fill_npg()

p3
p3 <- ggsave("motif_length_220808.pdf",dpi=300,device="pdf",width =10,height = 8)

#---------------------------------------------------------------------------








