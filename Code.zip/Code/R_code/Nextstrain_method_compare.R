rm(list=ls())

# setwd("/home/dell-none/Desktop/0426jiqun")
# da<-read.csv('slope_all_SSR.csv',header = TRUE)
# 
# head(da)
setwd("/home/dell-none/Desktop/traditionnal_method")
aa_en <- read.csv('aa_entropy.csv',header = TRUE)
aa_ev <- read.csv('aa_event.csv',header = TRUE)
nt_en <- read.csv('nt_entropy.tsv',header = TRUE,sep='\t')
nt_ev <- read.csv('nt_event.tsv',header = TRUE,sep='\t')

head(nt_en)
head(nt_ev)


library(ggplot2)
library(RColorBrewer)
library(lubridate)
library(scales)
mytheme <- theme( panel.grid.major = element_blank(),
                  panel.grid.minor = element_blank(),
                 strip.text = element_text(size = 15),
                 panel.background = element_blank(),
                 panel.border=element_blank(),
                 axis.line.y.left = element_line(color = "black",size = 0.8),
                 axis.line.y.right = element_line(color = "black",size = 0.8),
                 axis.ticks.y.left = element_line(color = "black"),
                 axis.ticks.y.right = element_line(color = "black"),
                 axis.text = element_text(size = 16),
                 axis.text.x = element_text(  vjust = 0),
                 axis.title.x = element_blank(),
                 axis.title = element_text(size = 20),
                 legend.title = element_text(size = 18),
                 legend.text = element_text(size = 13),
                 plot.title = element_text(size=20),
                 legend.background = element_blank())

####duble_y_axis

nt <- ggplot()+
  
  geom_line(data=nt_en,aes(x=ncbi_pos,y = rescale(entropy,c(1,97))),color="#E64E00",alpha=0.6)+
  geom_line(data=nt_ev,aes(x=ncbi_pos,y = events),color="#3C5488B2")+
  scale_x_continuous(breaks=seq(0, 30000, 5000),
                     expand = c(0.001, 0.001))+
  # 
  ylab("Events")+
  scale_y_continuous(limits = c(1,97),
                     sec.axis = sec_axis(name = "Entropy",
                                         ~rescale(.,c(0.003,0.962))),
                     expand = c(0.001, 0.001))+
  labs(title='Nucleotide')+
  mytheme
nt <- ggsave("nt_diver.pdf",dpi=300,device="pdf",width =13.7,height = 6.00)



#------------------------------------------------------------------------------------
aa <- ggplot()+
  
  geom_line(data=aa_en,aes(x=ncbi_pos,y = rescale(entropy,c(1,97))),color="#E64E00",alpha=0.6)+
  geom_line(data=aa_ev,aes(x=ncbi_pos,y = events),color="#3C5488B2")+
  scale_x_continuous(breaks=seq(0, 30000, 5000),
                     expand = c(0.001, 0.001))+
  # 
  ylab("Events")+
  scale_y_continuous(limits = c(1,97),
                     sec.axis = sec_axis(name = "Entropy",
                                         ~rescale(.,c(0.003,0.962))),
                     expand = c(0.001, 0.001))+
  labs(title='Amino acid')+
  mytheme
aa<- ggsave("aa_diver.pdf",dpi=300,device="pdf",width =13.7,height = 6.00)
